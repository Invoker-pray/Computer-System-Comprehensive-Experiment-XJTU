运行automation.sh
