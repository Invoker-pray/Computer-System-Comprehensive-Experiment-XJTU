运行`bash automation.sh`可以完成实验４．

在脚本中使用了之前构建好的gem5，在上一次作业中已经提交过构建这个gem5的脚本.
