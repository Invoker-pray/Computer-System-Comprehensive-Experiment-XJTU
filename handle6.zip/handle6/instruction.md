首先通过运行env_prepare.sh，完成环境构建，然后运行run_lab6.sh，开始仿真并且获取运行结果。

剩余说明会在　https://github.com/Invoker-pray/Computer-System-Comprehensive-Experiment-XJTU 上展出。
